function functionCall()
    print("assets mananger is called")
end
