function functionCall()
    print("update from net is called")
end
